import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';

export default function Rondas() {
  const [rondas, setRondas] = useState([]);
  const [nombresEquipos, setNombresEquipos] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const data = localStorage.getItem('rondas');
    const nombres = localStorage.getItem('nombresEquipos');
    if (data) setRondas(JSON.parse(data));
    if (nombres) setNombresEquipos(JSON.parse(nombres));
  }, []);

  const guardarPartida = () => {
    const historial = JSON.parse(localStorage.getItem('partidasGuardadas') || '[]');
    const rondasActualizadas = JSON.parse(localStorage.getItem('rondas')) || [];
    const nuevaPartida = {
      fecha: new Date().toISOString(),
      rondas: rondasActualizadas,
      nombresEquipos,
      equipos: parseInt(localStorage.getItem('numEquipos')),
      pistas: parseInt(localStorage.getItem('numPistas'))
    };
    historial.push(nuevaPartida);
    localStorage.setItem('partidasGuardadas', JSON.stringify(historial));
  };

  const volverAConfiguracion = () => {
    guardarPartida();
    navigate('/configuracion');
  };

  const modificarEnfrentamiento = (rondaIdx, enfIdx) => {
    const enf = rondas[rondaIdx][enfIdx];

    Swal.fire({
      title: 'Modificar enfrentamiento',
      html: `
        <input id="equipoA" class="swal2-input" placeholder="Equipo A" value="${enf.equipoA}" />
        <input id="equipoB" class="swal2-input" placeholder="Equipo B" value="${enf.equipoB}" />
        <input id="pista" type="number" class="swal2-input" placeholder="Pista" value="${enf.pista}" />
        <input id="resultadoA" type="number" class="swal2-input" placeholder="Puntos Equipo A" value="${enf.resultadoA ?? ''}" />
        <input id="resultadoB" type="number" class="swal2-input" placeholder="Puntos Equipo B" value="${enf.resultadoB ?? ''}" />
      `,
      focusConfirm: false,
      preConfirm: () => {
        return {
          equipoA: document.getElementById('equipoA').value,
          equipoB: document.getElementById('equipoB').value,
          pista: parseInt(document.getElementById('pista').value),
          resultadoA: parseInt(document.getElementById('resultadoA').value),
          resultadoB: parseInt(document.getElementById('resultadoB').value)
        };
      }
    }).then(result => {
      if (result.isConfirmed) {
        const nuevasRondas = [...rondas];
        nuevasRondas[rondaIdx][enfIdx] = {
          ...nuevasRondas[rondaIdx][enfIdx],
          ...result.value
        };
        setRondas(nuevasRondas);
        localStorage.setItem('rondas', JSON.stringify(nuevasRondas));
        Swal.fire('¡Modificado!', 'El enfrentamiento ha sido actualizado.', 'success');
      }
    });
  };

  const modificarNombresEquipos = () => {
    const nuevosNombres = [...nombresEquipos];
    const htmlInputs = nuevosNombres.map((nombre, idx) => (
      `<input id="equipo-${idx}" class="swal2-input" placeholder="Equipo ${idx + 1}" value="${nombre}" />`
    )).join('');

    Swal.fire({
      title: 'Modificar nombres de equipos',
      html: htmlInputs,
      focusConfirm: false,
      preConfirm: () => {
        return nuevosNombres.map((_, idx) => document.getElementById(`equipo-${idx}`).value);
      }
    }).then(result => {
      if (result.isConfirmed) {
        const nuevosNombresFinal = result.value;
        setNombresEquipos(nuevosNombresFinal);
        localStorage.setItem('nombresEquipos', JSON.stringify(nuevosNombresFinal));

        const nuevasRondasActualizadas = rondas.map(ronda =>
          ronda.map(enf => ({
            ...enf,
            equipoA: reemplazarNombre(enf.equipoA, nombresEquipos, nuevosNombresFinal),
            equipoB: reemplazarNombre(enf.equipoB, nombresEquipos, nuevosNombresFinal)
          }))
        );

        setRondas(nuevasRondasActualizadas);
        localStorage.setItem('rondas', JSON.stringify(nuevasRondasActualizadas));

        Swal.fire('¡Actualizado!', 'Los nombres de los equipos se han modificado.', 'success');
      }
    });
  };

  const reemplazarNombre = (nombreViejo, listaVieja, listaNueva) => {
    const idx = listaVieja.indexOf(nombreViejo);
    return idx !== -1 ? listaNueva[idx] : nombreViejo;
  };

  const borrarTodo = () => {
    Swal.fire({
      title: '¿Estás seguro?',
      text: 'Se borrará la partida actual, pero se mantendrán las partidas guardadas anteriormente.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, borrar todo',
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.removeItem('rondas');
        localStorage.removeItem('numEquipos');
        localStorage.removeItem('numPistas');
        localStorage.removeItem('nombresEquipos');
        Swal.fire('¡Borrado!', 'El torneo ha sido reiniciado.', 'success').then(() => {
          navigate('/configuracion');
        });
      }
    });
  };

  const volverSinGuardar = () => {
    Swal.fire({
      title: '¿Estás seguro?',
      text: 'Si vuelves ahora, los datos actuales no se guardarán y no se conservarán en el historial.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, volver sin guardar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.removeItem('rondas');
        localStorage.removeItem('numEquipos');
        localStorage.removeItem('numPistas');
        localStorage.removeItem('nombresEquipos');
        navigate('/configuracion');
      }
    });
  };

  if (!rondas || rondas.length === 0) {
    return (
      <div className="p-4 text-center">
        <h2 className="text-2xl font-bold text-red-700">Sin datos disponibles</h2>
        <p className="text-gray-600">Asegúrate de haber generado los enfrentamientos en la configuración.</p>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="text-3xl font-bold text-green-800 mb-6">Rondas del Torneo</h2>

      <div className="mb-4 flex flex-wrap gap-4">
        <button onClick={borrarTodo} className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
          Borrar Todo
        </button>
        <button onClick={modificarNombresEquipos} className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
          Modificar Nombres Equipos
        </button>
        <button
          onClick={() => navigate('/clasificacion')}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Ir a Clasificación
        </button>
        <button
          onClick={volverSinGuardar}
          className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700"
        >
          Volver sin guardar
        </button>
        <button
          onClick={volverAConfiguracion}
          className="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700"
        >
          Guardar y Volver
        </button>
      </div>

      {rondas.map((ronda, rondaIdx) => (
        <div key={rondaIdx} className="mb-6 border p-4 rounded shadow-md">
          <h3 className="text-xl font-semibold text-blue-700 mb-2">Ronda {rondaIdx + 1}</h3>
          <ul className="space-y-3">
            {ronda.map((enf, enfIdx) => (
              <li key={enfIdx} className="flex flex-col md:flex-row md:items-center justify-between bg-gray-100 p-2 rounded space-y-2 md:space-y-0">
                <div className="flex-1">
                  <strong>{enf.equipoA}</strong> vs <strong>{enf.equipoB}</strong> | Pista: {enf.pista}
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    placeholder="A"
                    className="w-16 p-1 border rounded text-center"
                    value={enf.resultadoA ?? ''}
                    onChange={(e) => {
                      const nuevasRondas = [...rondas];
                      nuevasRondas[rondaIdx][enfIdx].resultadoA = parseInt(e.target.value) || 0;
                      setRondas(nuevasRondas);
                      localStorage.setItem('rondas', JSON.stringify(nuevasRondas));
                    }}
                  />
                  <span>-</span>
                  <input
                    type="number"
                    placeholder="B"
                    className="w-16 p-1 border rounded text-center"
                    value={enf.resultadoB ?? ''}
                    onChange={(e) => {
                      const nuevasRondas = [...rondas];
                      nuevasRondas[rondaIdx][enfIdx].resultadoB = parseInt(e.target.value) || 0;
                      setRondas(nuevasRondas);
                      localStorage.setItem('rondas', JSON.stringify(nuevasRondas));
                    }}
                  />
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => modificarEnfrentamiento(rondaIdx, enfIdx)}
                    className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded"
                  >
                    Modificar
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}



