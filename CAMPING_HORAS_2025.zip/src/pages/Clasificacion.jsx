import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Clasificacion() {
  const [clasificacion, setClasificacion] = useState([]);
  const [nombresEquipos, setNombresEquipos] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const data = localStorage.getItem('rondas');
    const nombres = localStorage.getItem('nombresEquipos');
    const clasif = {};

    if (nombres) setNombresEquipos(JSON.parse(nombres));

    if (data) {
      const rondas = JSON.parse(data);

      rondas.flat().forEach((enf) => {
        const { equipoA, equipoB, resultadoA, resultadoB } = enf;

        if (!clasif[equipoA]) clasif[equipoA] = { nombre: equipoA, jugados: 0, ganados: 0, empatados: 0, perdidos: 0, puntosAFavor: 0, puntosEnContra: 0 };
        if (!clasif[equipoB]) clasif[equipoB] = { nombre: equipoB, jugados: 0, ganados: 0, empatados: 0, perdidos: 0, puntosAFavor: 0, puntosEnContra: 0 };

        if (typeof resultadoA === 'number' && typeof resultadoB === 'number') {
          clasif[equipoA].jugados++;
          clasif[equipoB].jugados++;
          clasif[equipoA].puntosAFavor += resultadoA;
          clasif[equipoA].puntosEnContra += resultadoB;
          clasif[equipoB].puntosAFavor += resultadoB;
          clasif[equipoB].puntosEnContra += resultadoA;

          if (resultadoA > resultadoB) {
            clasif[equipoA].ganados++;
            clasif[equipoB].perdidos++;
          } else if (resultadoA < resultadoB) {
            clasif[equipoB].ganados++;
            clasif[equipoA].perdidos++;
          } else {
            clasif[equipoA].empatados++;
            clasif[equipoB].empatados++;
          }
        }
      });

      const lista = Object.values(clasif).map((equipo) => ({
        ...equipo,
        puntos: equipo.ganados * 3 + equipo.empatados,
        diferencial: equipo.puntosAFavor - equipo.puntosEnContra,
        alias: equipo.nombre,
      }));

      lista.sort((a, b) => b.puntos - a.puntos || b.diferencial - a.diferencial);
      setClasificacion(lista);
    }
  }, []);

  const getFilaEstilo = (idx) => {
    if (idx === 0) return 'bg-yellow-500 font-bold';   // 🥇
    if (idx === 1) return 'bg-gray-300 font-semibold';  // 🥈
    if (idx === 2) return 'bg-orange-300 font-semibold';  // 🥉
    return 'odd:bg-white even:bg-gray-100';             // resto
  };

  const getPosicionIcono = (idx) => {
    if (idx === 0) return '🥇';
    if (idx === 1) return '🥈';
    if (idx === 2) return '🥉';
    return idx + 1;
  };

  return (
    <div className="p-4 font-[Poppins]">
      <h2 className="text-3xl font-bold text-green-800 mb-6">Clasificación</h2>

      {clasificacion.length === 0 ? (
        <p className="text-gray-600">No hay datos suficientes para mostrar la clasificación.</p>
      ) : (
        <>
          <table className="min-w-full border text-center mb-6 shadow-lg rounded overflow-hidden">
            <thead>
              <tr className="bg-green-200 text-gray-800">
                <th className="px-2 py-1 border">#</th>
                <th className="px-2 py-1 border">Equipo</th>
                <th className="px-2 py-1 border">Jugados</th>
                <th className="px-2 py-1 border">Ganados</th>
                <th className="px-2 py-1 border">Perdidos</th>
                <th className="px-2 py-1 border">Empatados</th>
                <th className="px-2 py-1 border">A favor</th>
                <th className="px-2 py-1 border">En contra</th>
                <th className="px-2 py-1 border">+/-</th>
                <th className="px-2 py-1 border">Puntos</th>
              </tr>
            </thead>
            <tbody>
              {clasificacion.map((equipo, idx) => (
                <tr
                  key={equipo.nombre}
                  className={`${getFilaEstilo(idx)} ${idx < 3 ? 'animate-top3' : ''}`}
                >
                  <td className="border px-2 py-1">{getPosicionIcono(idx)}</td>
                  <td className="border px-2 py-1">{equipo.alias}</td>
                  <td className="border px-2 py-1">{equipo.jugados}</td>
                  <td className="border px-2 py-1">{equipo.ganados}</td>
                  <td className="border px-2 py-1">{equipo.perdidos}</td>
                  <td className="border px-2 py-1">{equipo.empatados}</td>
                  <td className="border px-2 py-1">{equipo.puntosAFavor}</td>
                  <td className="border px-2 py-1">{equipo.puntosEnContra}</td>
                  <td className="border px-2 py-1">{equipo.diferencial}</td>
                  <td className="border px-2 py-1">{equipo.puntos}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex justify-center">
            <button
              onClick={() => navigate('/rondas')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded shadow"
            >
              Volver a Enfrentamientos
            </button>
          </div>
        </>
      )}
    </div>
  );
}




