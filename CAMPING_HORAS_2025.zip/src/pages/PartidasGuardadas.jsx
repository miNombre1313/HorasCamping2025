import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

export default function PartidasGuardadas() {
  const [partidas, setPartidas] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const guardadas = JSON.parse(localStorage.getItem('partidasGuardadas') || '[]');
    // Ordenar por fecha descendente (más reciente primero)
    guardadas.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
    setPartidas(guardadas);
  }, []);

  const cargarPartida = (partida) => {
    localStorage.setItem('numEquipos', partida.equipos);
    localStorage.setItem('numPistas', partida.pistas);
    localStorage.setItem('nombresEquipos', JSON.stringify(partida.nombresEquipos));
    localStorage.setItem('rondas', JSON.stringify(partida.rondas));
    Swal.fire('Partida cargada', 'Has restaurado una partida anterior', 'success').then(() => {
      navigate('/rondas');
    });
  };

  const borrarPartida = (index) => {
    Swal.fire({
      title: '¿Eliminar esta partida?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar'
    }).then((result) => {
      if (result.isConfirmed) {
        const actualizadas = [...partidas];
        actualizadas.splice(index, 1);
        setPartidas(actualizadas);
        localStorage.setItem('partidasGuardadas', JSON.stringify(actualizadas));
        Swal.fire('Eliminada', 'La partida ha sido eliminada', 'success');
      }
    });
  };

  return (
    <div className="p-4">
      <h2 className="text-3xl font-bold text-green-800 mb-6">Partidas Guardadas</h2>
      {partidas.length === 0 ? (
        <p className="text-gray-600">No hay partidas guardadas disponibles.</p>
      ) : (
        <ul className="space-y-4">
          {partidas.map((partida, idx) => (
            <li key={idx} className="border p-4 rounded shadow-md">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">Fecha: {new Date(partida.fecha).toLocaleString()}</p>
                  <p className="text-sm">Equipos: {partida.equipos} | Pistas: {partida.pistas}</p>
                </div>
                <div className="space-x-2">
                  <button
                    onClick={() => cargarPartida(partida)}
                    className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
                  >
                    Cargar
                  </button>
                  <button
                    onClick={() => borrarPartida(idx)}
                    className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      <button
        onClick={() => navigate('/configuracion')}
        className="mt-6 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Volver a Configuración
      </button>
    </div>
  );
}