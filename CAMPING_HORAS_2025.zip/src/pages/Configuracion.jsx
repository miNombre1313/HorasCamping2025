import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

export default function Configuracion() {
  const navigate = useNavigate();
  const [equipos, setEquipos] = useState(16);
  const [pistas, setPistas] = useState(11);
  const [nombresEquipos, setNombresEquipos] = useState([]);

  useEffect(() => {
    const nuevosNombres = Array.from({ length: equipos }, (_, i) => `Equipo ${i + 1}`);
    setNombresEquipos(nuevosNombres);
  }, [equipos]);

  const handleNombreCambio = (index, nuevoNombre) => {
    const actualizados = [...nombresEquipos];
    actualizados[index] = nuevoNombre;
    setNombresEquipos(actualizados);
  };

  const generarEnfrentamientos = () => {
    const enfrentamientos = [];
    const historialPistas = Array(equipos).fill(null).map(() => []);
    const repeticionesPorPista = Array(equipos).fill(null).map(() => ({}));
    const errores = [];

    const emparejamientos = [];
    for (let i = 0; i < equipos; i++) {
      for (let j = i + 1; j < equipos; j++) {
        const localPrimero = Math.random() < 0.5;
        emparejamientos.push(localPrimero ? [i, j] : [j, i]);
      }
    }

    let rondaNumero = 1;

    while (emparejamientos.length > 0) {
      const ronda = [];
      const equiposUsados = new Set();
      const pistasUsadasEnRonda = new Set();

      for (let i = 0; i < emparejamientos.length; i++) {
        const [a, b] = emparejamientos[i];
        if (!equiposUsados.has(a) && !equiposUsados.has(b)) {
          const pistasDisponibles = Array.from({ length: pistas }, (_, idx) => idx + 1).filter(p => {
            return (
              !pistasUsadasEnRonda.has(p) &&
              (repeticionesPorPista[a][p] || 0) < 2 &&
              (repeticionesPorPista[b][p] || 0) < 2 &&
              historialPistas[a].at(-1) !== p &&
              historialPistas[b].at(-1) !== p
            );
          });

          let pistaAsignada = pistasDisponibles[Math.floor(Math.random() * pistasDisponibles.length)];

          if (!pistaAsignada) {
            const opcionesForzadas = Array.from({ length: pistas }, (_, idx) => idx + 1).filter(p => !pistasUsadasEnRonda.has(p));
            pistaAsignada = opcionesForzadas[Math.floor(Math.random() * opcionesForzadas.length)];
            errores.push(`⚠️ Ronda ${rondaNumero}: ${nombresEquipos[a]} vs ${nombresEquipos[b]} asignados forzadamente a pista ${pistaAsignada}`);
          }

          if (pistasUsadasEnRonda.has(pistaAsignada)) {
            errores.push(`⚠️ Ronda ${rondaNumero}: Pista ${pistaAsignada} ya está siendo usada en esta ronda.`);
            continue;
          }

          pistasUsadasEnRonda.add(pistaAsignada);
          historialPistas[a].push(pistaAsignada);
          historialPistas[b].push(pistaAsignada);
          repeticionesPorPista[a][pistaAsignada] = (repeticionesPorPista[a][pistaAsignada] || 0) + 1;
          repeticionesPorPista[b][pistaAsignada] = (repeticionesPorPista[b][pistaAsignada] || 0) + 1;

          ronda.push({
            equipoA: nombresEquipos[a],
            equipoB: nombresEquipos[b],
            pista: pistaAsignada,
            resultadoA: null,
            resultadoB: null
          });

          equiposUsados.add(a);
          equiposUsados.add(b);
          emparejamientos.splice(i, 1);
          i--;
        }
      }

      enfrentamientos.push(ronda);
      rondaNumero++;
    }

    const vistos = new Set();
    enfrentamientos.flat().forEach(enf => {
      const key = [enf.equipoA, enf.equipoB].sort().join('-');
      if (vistos.has(key)) {
        errores.push(`⚠️ Enfrentamiento repetido entre ${enf.equipoA} y ${enf.equipoB}`);
      }
      vistos.add(key);
    });

    const fecha = new Date().toISOString();
    const partida = {
      fecha,
      equipos,
      pistas,
      nombresEquipos,
      rondas: enfrentamientos
    };

    localStorage.setItem('numEquipos', equipos);
    localStorage.setItem('numPistas', pistas);
    localStorage.setItem('nombresEquipos', JSON.stringify(nombresEquipos));
    localStorage.setItem('rondas', JSON.stringify(enfrentamientos));

    if (errores.length > 0) {
      Swal.fire({
        title: 'Advertencias detectadas',
        icon: 'warning',
        html: errores.join('<br>'),
        confirmButtonText: 'Aceptar y continuar'
      }).then(() => {
        navigate('/rondas');
      });
    } else {
      navigate('/rondas');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center space-y-6 p-4">
      <h2 className="text-3xl font-semibold text-green-800">Configuración del Torneo</h2>

      <div className="flex flex-col items-start space-y-2">
        <label>
          Número de equipos:
          <input
            type="number"
            value={equipos}
            onChange={(e) => setEquipos(Number(e.target.value))}
            min="2"
            max="32"
            className="ml-2 p-1 border rounded"
          />
        </label>
        <label>
          Número de pistas:
          <input
            type="number"
            value={pistas}
            onChange={(e) => setPistas(Number(e.target.value))}
            min="1"
            max="20"
            className="ml-2 p-1 border rounded"
          />
        </label>
      </div>

      <div className="w-full max-w-md">
        <h3 className="text-xl font-semibold text-blue-700 mt-4 mb-2">Nombres de los Equipos:</h3>
        <table className="w-full border rounded">
          <thead>
            <tr className="bg-gray-200">
              <th className="border px-2 py-1">#</th>
              <th className="border px-2 py-1">Nombre</th>
            </tr>
          </thead>
          <tbody>
            {nombresEquipos.map((nombre, idx) => (
              <tr key={idx}>
                <td className="border px-2 py-1 text-center">{idx + 1}</td>
                <td className="border px-2 py-1">
                  <input
                    type="text"
                    value={nombre}
                    onChange={(e) => handleNombreCambio(idx, e.target.value)}
                    className="w-full p-1 border rounded"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={generarEnfrentamientos}
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          Generar Enfrentamientos
        </button>
        <button
          onClick={() => navigate('/partidasguardadas')}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Buscar Partidas
        </button>
        <button
          onClick={() => navigate('/')}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Salir
        </button>
      </div>
    </div>
  );
}


